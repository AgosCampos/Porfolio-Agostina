Portfolio personal 

A continuación se presentará un portfolio personal con el fin de brindar un poco más de información profesional al lector.

En este trabajo se utilizaron métodos de diseño y desarrollo, aprendidos a lo largo del curso.

En el portfolio se encuentran secciones como:
  La presentación: donde doy la bienvenida al portfolio y cuento sobre mí profesión.

  Conocimientos: donde explico las herramientas en las que me desenvuelvo.

  Proyectos: se encuentran todos los proyectos que hice a lo largo de mí vida profesional.

  Contacto: donde puede comunicarse conmigo por cualquier duda